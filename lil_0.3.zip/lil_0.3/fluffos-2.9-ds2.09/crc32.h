#ifndef CRC32_H
#define CRC32_H

/*
 * crc32.c
 */
UINT32 compute_crc32 (unsigned char *, int);

#endif
