string test_desc;

void
describe_test(string desc)
{
    test_desc = desc;
}

string
query_test_info()
{
    return test_desc;
}
