void do_tests() {
    if (this_player())
    ASSERT(intp(query_idle(this_player())));
}
