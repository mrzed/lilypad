void do_tests() {
    ASSERT(master());
    ASSERT(objectp(master()));
}
