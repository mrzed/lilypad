void do_tests() {
#ifdef __CACHE_STATS__
    ASSERT(stringp(cache_stats()));
#endif
}
