#pragma strict_types

foo() {
}
