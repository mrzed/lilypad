void foo() {
    (: $-1 :);
}
