class foo {
    int x;
}

void foo() {
    foo y;
    y->z;
}
