void foo() {
    switch (1) {
    default:
    default:
    }
}
